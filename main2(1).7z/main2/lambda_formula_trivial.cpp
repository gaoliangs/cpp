#include <vector>
#include "symbolic.h"

std::vector<SymbolicExpression> la;

void calculate_la() {
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
    la.push_back(0);
}
