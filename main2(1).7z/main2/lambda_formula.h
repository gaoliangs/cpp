#ifndef LAMBDA_FORMULA_H
#define LAMBDA_FORMULA_H

#include <vector>
#include <string>

std::vector<std::string> getLambdaFormula();

#endif // LAMBDA_FORMULA_H
