#ifndef LAMBDA_FORMULA_TRIVIAL_H
#define LAMBDA_FORMULA_TRIVIAL_H

#include <vector>
#include <string>

std::vector<std::string> getLambdaFormulaTrivial();

#endif // LAMBDA_FORMULA_TRIVIAL_H
