#include "variables.h"

Variables getVariables() {
    Variables vars;

    vars.t = {t0, t1, t2, t3};
    vars.c = {c0, c1, c2, c3};
    vars.tl = {tl2, tl5, tl3};

    return vars;
}
